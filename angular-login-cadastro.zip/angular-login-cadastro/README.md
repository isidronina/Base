# Login e cadastro — componentes Angular standalone

Componentes preparados para projetos Angular modernos (standalone) e formulários reativos.

## Arquivos

- `pages/login/login.component.ts|html|css`
- `pages/cadastro/cadastro.component.ts|html|css`
- `app.routes.example.ts`: exemplo de rotas
- `styles.global.example.css`: ajuste global necessário

## Como integrar

1. Copie a pasta `pages` para `src/app/pages/`.
2. Copie as rotas de `app.routes.example.ts` para `src/app/app.routes.ts` (ajuste os caminhos dos imports se a sua estrutura for diferente). Se já existem rotas, acrescente somente as rotas `login` e `cadastro`, sem apagar as atuais.
3. Confira se o projeto renderiza as rotas com `<router-outlet />` no componente raiz e se o `provideRouter(routes)` está configurado no `app.config.ts` (ou a configuração equivalente do seu projeto).
4. Copie as regras de `styles.global.example.css` para `src/styles.css`.
5. Coloque as imagens em `public/assets/imagem-login.jpg` e `public/assets/imagem-cadastro.jpg`. Os templates usam `/assets/imagem-login.jpg` e `/assets/imagem-cadastro.jpg`. Se o projeto tiver configuração de assets diferente, ajuste os caminhos.
6. Adicione as fontes no `<head>` de `src/index.html`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Manrope:wght@700;800&display=swap" rel="stylesheet">
```

7. Execute `ng serve` e abra `/login` ou `/cadastro`.

## O que já funciona

- Navegação Angular entre login e cadastro.
- Validação de campos obrigatórios e formato do e-mail.
- Mostrar/ocultar senha no login.
- Validação de senha com mínimo de 8 caracteres, confirmação de senha e aceite obrigatório dos termos no cadastro.
- Mensagens de erro acessíveis e feedback no envio.

## Importante: backend ainda necessário

Esses componentes não autenticam usuários nem gravam contas. Ao enviar formulários válidos, exibem uma mensagem explicando que falta conectar o backend/serviço de autenticação ou cadastro. Isso evita simular um login real sem validar credenciais. A recuperação de senha e os links de termos/privacidade também precisam ser ligados às páginas ou serviços reais do seu projeto. O link “Voltar ao site” usa `routerLink="/"`; ajuste para a rota real da página inicial.

O layout foi mantido em desktop com painel de imagem de 600px, conforme solicitado anteriormente.
