import { CommonModule } from '@angular/common';
import { AbstractControl, Component, ValidationErrors, ValidatorFn, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';

const senhasIguaisValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const senha = control.get('senha')?.value as string | undefined;
  const confirmarSenha = control.get('confirmarSenha')?.value as string | undefined;
  if (!senha || !confirmarSenha) return null;
  return senha === confirmarSenha ? null : { senhasDiferentes: true };
};

@Component({
  selector: 'app-cadastro',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './cadastro.component.html',
  styleUrl: './cadastro.component.css',
})
export class CadastroComponent {
  private readonly fb = inject(FormBuilder);

  readonly form = this.fb.nonNullable.group({
    nome: ['', Validators.required],
    sobrenome: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    senha: ['', [Validators.required, Validators.minLength(8)]],
    confirmarSenha: ['', [Validators.required, Validators.minLength(8)]],
    aceitarTermos: [false, Validators.requiredTrue],
  }, { validators: senhasIguaisValidator });

  mensagem = '';

  onSubmit(): void {
    this.mensagem = '';

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.mensagem = this.form.hasError('senhasDiferentes')
        ? 'As senhas não são iguais. Confira e tente de novo.'
        : 'Confira os campos obrigatórios, o e-mail, as senhas e o aceite dos termos.';
      return;
    }

    // Os dados não são enviados nem armazenados: falta integrar o backend de cadastro.
    this.mensagem = 'Cadastro validado no navegador. Para criar a conta de verdade, conecte o serviço de cadastro do sistema.';
  }
}
