import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  private readonly fb = inject(FormBuilder);

  readonly form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    senha: ['', Validators.required],
  });

  mostrarSenha = false;
  mensagem = '';

  onSubmit(): void {
    this.mensagem = '';

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.mensagem = 'Confira o e-mail e preencha sua senha.';
      return;
    }

    // A validação visual funciona, mas a autenticação real exige um backend/serviço.
    this.mensagem = 'Formulário validado. Para entrar na conta, conecte a autenticação do sistema.';
  }

  recuperarSenha(): void {
    this.mensagem = 'A recuperação de senha ainda precisa ser conectada ao serviço do sistema.';
  }
}
